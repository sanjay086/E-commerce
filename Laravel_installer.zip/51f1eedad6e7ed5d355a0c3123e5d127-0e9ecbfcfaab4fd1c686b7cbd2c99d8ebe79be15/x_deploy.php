<?php
/**
 * deploy.php
 * https://deployer.org/
 *
 * composer require deployer/deployer --dev
 * composer require deployer/recipes --dev
 *
 * Deploy your project
 * vendor/bin/dep deploy
 *
 * Note that the this does not work in the windows shell. I personaly use the windows subsystem for linux for it.
 * 
 * The first deploy will fail, you need to ssh into the server and create your .env with
 * nano /var/www/example.com/shared/.env
 *
 * Connect to host through ssh
 * vendor/bin/dep ssh
 */

namespace Deployer;

require 'recipe/laravel.php';
require 'recipe/cachetool.php';
require 'recipe/npm.php';

// Project name
set('application', 'example');

// Project repository
set('repository', 'git@domain.com:username/repository.git');

// Shared files/dirs between deploys
add('shared_files', []);
add('shared_dirs', []);

// Writable dirs by web server
add('writable_dirs', []);


// Hosts
host('example.com')
    ->user('root')
    ->set('deploy_path', '/var/www/example.com');


task('artisan:optimize', function() {
    writeln('skipping artisan:opzimize'); 
    // skipping because view:cache and config:cache is already in the default queue from deployer.php
    // and we added route:cache ourself
});

task('cachetool:clear:opcache', function() {
    run("service php7.4-fpm reload",  ['timeout' => 600]);
});

desc('Restarting Echo Server');
task('echo-server:restart', function () {
    run('supervisorctl restart example-laravel-echo');
});

desc('Execute npm run production');
task('build', function () {
    run("cd {{release_path}} && {{bin/npm}} run production",  ['timeout' => 600]);
});


after('deploy:writable', 'npm:install');
after('deploy:writable', 'build');


before('deploy:symlink', 'artisan:route:cache');
before('deploy:symlink', 'artisan:migrate');

after('deploy:symlink', 'cachetool:clear:opcache');
after('deploy:symlink', 'artisan:queue:restart');
after('deploy:symlink', 'echo-server:restart');


// [Optional] if deploy fails automatically unlock.
after('deploy:failed', 'deploy:unlock');

after('rollback', 'cachetool:clear:opcache');
after('rollback', 'artisan:config:cache');
after('rollback', 'artisan:view:cache');
after('rollback', 'artisan:route:cache');
after('rollback', 'artisan:queue:restart');
after('rollback', 'echo-server:restart');