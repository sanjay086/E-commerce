# Bonus Tipps

## Running out of space on the server
I run out of space on my 20GB server once in a while.
You can check your free storage with `df -h`

### Finding the biggest files
I recommend to install ncdu with `apt install ncdu` it shows you the size of every folder and lets you navigate through them.

### /var/log/journal
The journals size was multible GB in my case. I run `journalctl` to look what's inside it and there where a bunch of failed ssh login attempts. I delete everything thats over 100MB in my crontab now daily.

```
0 8 * * * journalctl --vacuum-size=100M
```

### /var/lib/mysql/binlog.000001
The database binlog has reached multible GB on my server. My laravel project uses telescope which inserts 1GB a day. thats probably why.
I changed my mysql config in `/etc/mysql/mysql.conf.d/mysqld.cnf` to reduce the size. *The settings already exist at the end of the file just uncommend it and change the values.*

```
binlog_expire_logs_seconds = 86400
max_binlog_size   = 100M
```
after that restart the mysql service `service mysql restart`

## Specify the php version for composer
I have php 8 installed localy but my server runs with php 7. to prevent composer to install packages that only work in php 8 you can specify the php version you have in your composer.json. I also had problems installing deployer with php 8 as the latest release only runs on php 7. so composer installed a very old version of deployer.
```
"config": {
    "platform": {
        "php": "7.4.3"
    }
},
```


