# Ubuntu 20 LTS Server Setup for Laravel

# Login as root user

sudo su -


# Update list of available packages

apt update


# Install node.js

curl -sL https://deb.nodesource.com/setup_16.x | sudo -E bash -
apt install nodejs



# Install MySQL

apt install mysql-server


# Configure MySQL

mysql -u root <<-EOF
CREATE DATABASE databasename;
CREATE USER 'example_laravel'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password';
GRANT ALL PRIVILEGES ON databasename.* TO 'example_laravel'@'localhost';
EOF


# Install nginx

apt install nginx


# Configure nginx

cp /etc/nginx/sites-available/default /etc/nginx/sites-available/example.com
nano /etc/nginx/sites-available/example.com
ln -s /etc/nginx/sites-available/example.com /etc/nginx/sites-enabled/
nginx -t
service nginx restart


# Configure Gzip

cat > /etc/nginx/conf.d/gzip.conf << EOF
gzip_comp_level 5;
gzip_min_length 256;
gzip_proxied any;
gzip_vary on;
gzip_types
application/atom+xml
application/javascript
application/json
application/rss+xml
application/vnd.ms-fontobject
application/x-font-ttf
application/x-web-app-manifest+json
application/xhtml+xml
application/xml
font/opentype
image/svg+xml
image/x-icon
text/css
text/plain
text/x-component;
EOF
service nginx restart 


# Configure HTTPS 

sudo apt install certbot python3-certbot-nginx
certbot --nginx

# after installing ssl you can enable http2. add "http2" 
# in the file /etc/nginx/sites-available/example.com near the bottom: 
# listen 443 ssl http2; # managed by Certbot


# Install php

apt install php-fpm
apt install php-mysql php-common php-mbstring php-xml php-zip php-bcmath zip unzip php-curl

curl -sS https://getcomposer.org/installer -o ~/composer-setup.php
php ~/composer-setup.php --install-dir=/usr/local/bin --filename=composer
rm ~/composer-setup.php 



# Configure php

sed -i 's/^upload_max_filesize.*/upload_max_filesize = 10M/' /etc/php/7.4/fpm/php.ini
sed -i 's/^post_max_size.*/post_max_size = 10M/' /etc/php/7.4/fpm/php.ini

service php7.4-fpm restart


# Install supervisor

apt install supervisor


# Configure supervisor

nano /etc/supervisor/conf.d/example-laravel.conf
supervisorctl reread
supervisorctl update
supervisorctl start example-laravel-worker:*


# Configure crons

crontab -e


# Add known hosts

ssh-keyscan -H github.com >> ~/.ssh/known_hosts
ssh-keyscan -H bitbucket.org >> ~/.ssh/known_hosts
ssh-keyscan -H gitlab.com >> ~/.ssh/known_hosts


# Setup ssh key

ssh-keygen -b 2048 -t rsa -f ~/.ssh/id_rsa -q -N ""

# Output the public ssh key in the console
# In order for this maschine to gain read-only access to your repositories you need to copy this key to
# - Bitbucket: under Project -> Settings -> Access keys

cat ~/.ssh/id_rsa.pub